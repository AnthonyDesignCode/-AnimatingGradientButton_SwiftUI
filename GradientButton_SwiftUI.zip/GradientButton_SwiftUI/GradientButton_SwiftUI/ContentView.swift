//
//  ContentView.swift
//  GradientButton_SwiftUI
//
//  Created by Immature Inc on 20/04/2020.
//  Copyright © 2020 AnthonyDesignCode.io. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack(spacing: 20) {
            Spacer()
            
            Button(action: {
                // so something
            }) {
                Text("Learn more SwiftUI")
                    .font(.subheadline)
                    .foregroundColor(.white)
            }
            .frame(width: 220, height: 60).background(AnimateButton())
            .cornerRadius(10)
            .padding(.bottom, 20)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct AnimateButton: View {
    
    let timer = Timer.publish(every: 1, on: .main, in: .default).autoconnect()
    
    let colors = [Color.green,
                  Color.blue,
                  Color.blue,
                  Color.purple,
                  Color.pink,
                  Color.red,
                  Color.orange
    ]
    
    @State private var start = UnitPoint(x: 0, y: -2)
    @State private var end = UnitPoint(x: 4, y: 0)
    
    var body: some View {
        
        LinearGradient(gradient: Gradient(colors: colors), startPoint: start, endPoint: end)
            .animation(Animation.easeInOut(duration: 6)
                .repeatForever())
            .onReceive(timer) { _ in
            
                self.start = UnitPoint(x: 4, y: 0)
                self.end = UnitPoint(x: 0, y: 2)
                self.start = UnitPoint(x: -4, y: 20)
                self.end = UnitPoint(x: 4, y: 0)
            
        }
    }
}
